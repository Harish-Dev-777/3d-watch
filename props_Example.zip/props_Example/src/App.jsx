import ProfileCard from "./Components/ProfileCard";

let App = () => {
  return (
    <div>
      <div className="container">
        <ProfileCard
          productName={"mobile"}
          price={25000}
          color={"Black"}
        ></ProfileCard>
        <ProfileCard
          productName={"Laptop"}
          price={50000}
          color={"Silver"}
        ></ProfileCard>
        <ProfileCard
          productName={"watch"}
          price={10000}
          color={"Silver"}
        ></ProfileCard>
      </div>
      }
    </div>
  );
};
export default App;
